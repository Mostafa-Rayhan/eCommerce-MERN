import React from 'react';

const Loading = () => {
    return (
        <div style={{width:"100%", textAlign:"center", marginTop:"100px" }}>
<h5>Loading...</h5>

        </div>
    );
};

export default Loading;
